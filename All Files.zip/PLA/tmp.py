people = [
    {"lastName": "Andrienko", "firstName": "Yuri", "salary": 123456},
    {"lastName": "Pupkun", "firstName": "Vasya", "salary": 77777},
    {"lastName": "Andrey", "firstName": "Andreev", "salary": 300000}
]

zp = people[2]
for p in people:
    if p['salary'] > zp['salary']:
        zp = p
#print(int(p['salary']))
print(zp["salary"])