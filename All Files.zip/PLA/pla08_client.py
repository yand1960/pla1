# import pla07_functions
#
# print(pla07_functions.hypot(6, 8))

# import pla07_functions as myfun
# import datetime as dt
# print(myfun.hypot(6, 8), dt.datetime.now())

from pla07_functions import hypot, cathet
from datetime import datetime as dt
print(hypot(6, 8), dt.now())