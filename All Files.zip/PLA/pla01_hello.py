print("Hello, world!")
x = 2
y = 2
x = (x + 1) * 12 / 3.14159
z = x * y
print(z)